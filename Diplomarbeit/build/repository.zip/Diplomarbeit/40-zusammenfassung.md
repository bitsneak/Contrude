# Zusammenfassung

Hier schreiben Sie gemeinsam eine Zusammenfassung der gesamten Arbeit, in der sie auf einigen (wenigen) Seiten nochmals die Aufgabenstellung und die durch Ihre Diplomarbeit gefundenen Resultate beschreiben, wobei in der auch auf den Entstehungsprozess, persönliche Erfahrungen, Probleme bei der Durchführung,Verbesserungsmöglichkeiten, mögliche Erweiterungen usw. eingegangen werden kann.
War das Thema richtig gewählt, was wurde konkret erreicht, welche Punkte bliebenoffen und wie könnte von hier aus weitergearbeitet werden?

Dabei gehen Sie nicht ins Detail (dafür sind die Detailkapitel da) sondern beschreiben wie Ihre Teilaufgaben zur Lösung des Gesamtproblems beigetragen haben.

Zum Schluss geben Sie noch einen Ausblick was die nächsten Schritte sein könnten und wo man bei Ihrer Arbeit anknüpfen könnte.



## Lesen und lesen lassen

Wenn die Arbeit fertig ist, sollten Sie diese zunächst selbst nochmals vollständig undsorgfältig durchlesen, auch wenn man vielleicht das mühsam entstandene Produktlängst nicht mehr sehen möchte. Zusätzlich ist sehr zu empfehlen, auch einer weiterenPerson diese Arbeit anzutun – man wird erstaunt sein, wie viele Fehler man selbstüberlesen hat.
