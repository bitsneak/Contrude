# Aufgabenstellung 

## Auftraggeber
Wer ist der Auftraggeber, wie ist es zu dieser Arbeit gekommen, was verspricht sich der Auftraggeber davon

## Ausgangssituation

Eine allgemeine Aufgabenstellung 

* Was ist die derzeitige Situation ? 
* Wie wird derzeit gearbeitet ?


### So gehen Zitate

Einzel Zitat:  
[vgl. @leeb_einfuhrung_2016, S. 13]

Zitatsammlung:  
(vergleich dazu @heise oder @t3n)  
[vgl. @hattie_lernen_2013, S. 33-35; außerdem @walker_problem_2009, S. 6 f.]

Zitat ohne Autor  
Hattie sagte bla bla [-@hattie_lernen_2013]

Name des Autors mit Jahr in Klammern  
@hattie_lernen_2013 sagte einmal bla bla bla

Auch Videos kann man Zitieren wi Zum Biespiel hier [@Zatko15] in dieser Referenz.

### Systembeschreibung Y 

### Systembeschreibung Z 
