Diplomarbeit - CONTRUDE
